import os
from llama_cpp import Llama

class PromptEngine:
    def __init__(self, model_path):
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"找不到 LLM 模型檔：{model_path}")

        print(f"[LLM] 啟動精確替換引擎 (CPU 模式)...")
        self.llm = Llama(
            model_path=model_path,
            n_ctx=512,
            n_gpu_layers=0,
            verbose=False
        )

    def rewrite(self, user_input, experts_info):
        # Stage 1：LLM 語意正規化
        mapping_str = ""
        for info in experts_info:
            mapping_str += f"- {info['name']} -> {info['trigger']}\n"

        system_instruction = (
            "Role: You are a strict 'Text Substitution Robot'.\n"
            "Task: Substitute specific entity names in the user input with their corresponding 'Trigger Words'.\n\n"
            "RULES (CRITICAL):\n"
            "1. Identify the entities listed in the mapping table below.\n"
            "2. You MUST replace every identified entity with its 'REPLACE WITH' value.\n"
            "3. DO NOT translate, DO NOT paraphrase, and DO NOT add any extra words.\n"
            "4. If an entity has character variations (e.g., 台 vs 臺), treat them as identical and replace them.\n"
            "5. Output ONLY the processed sentence.\n\n"
            f"### MAPPING TABLE ###\n{mapping_str}"
        )

        prompt = f"<|im_start|>system\n{system_instruction}<|im_end|>\n<|im_start|>user\n{user_input}<|im_end|>\n<|im_start|>assistant\n"

        output = self.llm(
            prompt,
            max_tokens=256,
            stop=["<|im_end|>"],
            temperature=0.1,
            echo=False
        )
        p_mid = output['choices'][0]['text'].strip()
        print(f"[Stage 1] LLM 改寫結果：{p_mid}")

        # Stage 2：確定性後處理（保證觸發詞 100% 存在）
        p_final = self._deterministic_postprocess(p_mid, experts_info)
        print(f"[Stage 2] 後處理結果：{p_final}")

        return p_final

    def _deterministic_postprocess(self, p_mid, experts_info):
        result = p_mid
        appended = []

        for info in experts_info:
            name    = info["name"]
            trigger = info["trigger"]

            if name in result:
                # 分支一：名稱存在，替換成觸發詞
                result = result.replace(name, trigger)
                print(f"  [POST] 替換：{name} -> {trigger}")

            elif trigger not in result:
                # 分支二：名稱和觸發詞都不在，附加到尾端
                result = result + f", {trigger}"
                appended.append(trigger)
                print(f"  [POST] 附加：{trigger}")

            else:
                # 分支三：觸發詞已存在，跳過
                print(f"  [POST] 已存在，跳過：{trigger}")

        return result