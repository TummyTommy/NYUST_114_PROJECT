import torch
import json
from diffusers import DiffusionPipeline

# ── 1. 載入 pipe ──
model_id = "Qwen/Qwen-Image-2512"
print(" 正在載入模型：", model_id)

pipe = DiffusionPipeline.from_pretrained(
    model_id,
    torch_dtype=torch.bfloat16,
)
pipe.enable_model_cpu_offload()
pipe.set_progress_bar_config(disable=True)

# ── 2. 標籤映射 (確保與 CSV 的 label 欄位完全一致) ──
# 這裡建議檢查你的 JSON 裡是寫 "arch_1" 還是 "arch_01"
label_map = {f"arch{i:02d}": i-1 for i in range(1, 25)}
label_map["animal01"] = 24

num_classes = 25

# ── 3. 批次提取函式 ──
BATCH_SIZE = 32

def extract_embeddings_batch(texts: list[str]) -> torch.Tensor:
    all_embs = []
    for i in range(0, len(texts), BATCH_SIZE):
        batch = texts[i : i + BATCH_SIZE]
        with torch.no_grad():
            prompt_embeds, _ = pipe.encode_prompt(
                prompt=batch,
                device="cuda",
                num_images_per_prompt=1,
            )
        # Mean Pooling 取得語義向量
        emb = prompt_embeds.mean(dim=1).float().cpu() 
        all_embs.append(emb)
        print(f"  ⚡ 批次進度：{min(i+BATCH_SIZE, len(texts))}/{len(texts)}")
    return torch.cat(all_embs, dim=0)

# ── 4. 讀取 JSONL ──
def load_jsonl(filepath):
    items = []
    try:
        with open(filepath, "rb") as f:
            for i, raw_line in enumerate(f, 1):
                line = raw_line.decode("utf-8").strip()
                if not line: continue
                items.append(json.loads(line))
        print(f" 成功解析 {len(items)} 筆原始資料")
    except Exception as e:
        print(f" 讀取失敗: {e}")
    return items

# ── 5. 主流程 ──
items = load_jsonl("router_train_data02.json")

valid_texts  = []
valid_labels = []
skipped = 0

print(" 正在對齊標籤與過濾數據...")
for i, item in enumerate(items):
    text = item.get("text", "").strip()
    item_labels = item.get("label", []) # 可能是 ["arch_01", "animal_01"] 或 []

    if not text:
        skipped += 1
        continue

    target = torch.zeros(num_classes)
    has_unknown = False

    # 處理標籤
    for lbl in item_labels:
        lbl_clean = lbl.strip()
        if lbl_clean in label_map:
            target[label_map[lbl_clean]] = 1.0
        else:
            # 這是 debug 關鍵：印出到底是哪個標籤對不上
            print(f"   第 {i} 筆發現未知標籤: '{lbl_clean}'，此筆將被跳過")
            has_unknown = True
            break

    if has_unknown:
        skipped += 1
        continue

    valid_texts.append(text)
    valid_labels.append(target.unsqueeze(0))

print(f" 整理完成！有效資料：{len(valid_texts)} 筆，跳過：{skipped} 筆")

# ── 6. 執行提取並儲存 ──
if len(valid_texts) > 0:
    print(f" 開始為 {len(valid_texts)} 筆資料提取 3584 維特徵...")
    all_embeddings = extract_embeddings_batch(valid_texts)
    all_labels     = torch.cat(valid_labels, dim=0)

    torch.save(
        {"embeddings": all_embeddings, "labels": all_labels},
        "train_dataset.pt"
    )

    print(f"\n 特徵提取完成！")
    print(f"   embeddings shape：{all_embeddings.shape}")
    print(f"   labels shape：    {all_labels.shape}")
else:
    print(" 錯誤：沒有任何有效資料可以提取特徵，請檢查 JSON 標籤名稱。")