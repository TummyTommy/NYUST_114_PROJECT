import csv
import json
import random

CSV_FILE    = "categories.csv"
OUTPUT_FILE = "router_train_data02.json"


# ── 1. 單一專家模板（加入人物與環境雜訊） ──
TEMPLATES_SINGLE = [
    "{n1}",
    "我想看{n1}。",
    "這裡有{n1}。",
    "幫我生成{n1}的圖片。",
    "這是一張關於{n1}的照片。",
    # 加入人物動作雜訊
    "有一個人正在{n1}的前面拍照。",
    "遊客們聚集在{n1}門口參觀觀光。",
    "我在{n1}前方散步，感受歷史氣息。",
    "很多人在{n1}這裡打卡留念。",
    "一個攝影師正在捕捉{n1}的細節。",
    "在{n1}附近散步的行人。",
    "清晨的{n1}，前面沒什麼人。",
    "穿著校服的學生在{n1}前方集合。",
    "一名觀光客在{n1}門口露出驚訝的表情。",
    "我站在{n1}正前方，準備拍照。"
]

# ── 2. 混合專家模板（重點補強：加入你提到的描述方式） ──
TEMPLATES_MIXED = [
    "有一隻{n_ani}出現在{n_arch}附近。",
    "我看見{n_ani}飛過了{n_arch}。",
    "{n_arch}前方站著一隻{n_ani}。",
    "在{n_arch}旁邊發現了{n_ani}的蹤跡。",
    "一隻{n_ani}棲息在{n_arch}的屋頂上。",
    "這是一張包含{n_arch}與{n_ani}的照片。",
    # 針對你遇到的問題進行補強：加入複雜的人物語境
    "一個人在{n_arch}前方拍照，旁邊有一隻{n_ani}。",
    "遊客在{n_arch}觀光時，剛好看到一隻{n_ani}飛過。",
    "他在{n_arch}散步，意外發現附近的{n_ani}正在活動。",
    "這張照片拍到了一個人在{n_arch}前面，背景還有一隻{n_ani}。",
    "群眾在{n_arch}圍觀一隻出沒的{n_ani}。",
    "一位攝影師在{n_arch}取景，畫面上方剛好有{n_ani}。",
    "在{n_arch}的前方廣場，有一個人正驚奇地看著{n_ani}。",
    "某個下午，我在{n_arch}拍到了{n_ani}的身影。",
    "一隻{n_ani}從{n_arch}的圍牆邊跳出來，嚇到了旁邊拍照的人。",
    "描述：有一個人在{n_arch}前方，旁邊有一隻{n_ani}在動。"
]

# ── 3. 建議調整 NUM_SAMPLES ──
# 因為你有 25 個專家，600 筆資料平均每個專家分不到 24 筆。
# 建議提高到至少 2000 ~ 3000 筆，訓練效果會大幅提升。
NUM_SAMPLES = 2500

# 負樣本：與台灣特色完全無關
NEGATIVE_TEXTS = [
    "今天心情不錯。",
    "請幫我寫一段 Python 程式碼。",
    "車流很多的地方有人在拍照。",
    "這是一個無關的測試句子。",
    "我想吃晚餐。",
    "這台電腦的效能非常強大。",
    "量子力學是一個深奧的學科。",
    "幫我規劃一份健身計畫。",
    "今天股市大跌。",
    "A cat sitting on a sofa.",
    "Random text with no specific subject.",
    "Generate an abstract painting.",
    "A futuristic city at night.",
    "桌上有一杯咖啡。",
    "天空中有很多雲。",
]

def load_data(filepath):
    arch_list, animal_list = [], []
    try:
        with open(filepath, mode='r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            reader.fieldnames = [n.strip() for n in reader.fieldnames]

            for row in reader:
                label  = row.get('label', '').strip()
                c_name = row.get('name', '').strip()
                t_id   = row.get('trigger', '').strip()

                if not label or not c_name:
                    continue

                # 只加入非空的名稱
                names = [n for n in [c_name, t_id] if n]

                item = {"names": names, "label": label}

                if label.startswith('arch'):
                    arch_list.append(item)
                elif label.startswith('animal'):
                    animal_list.append(item)

    except FileNotFoundError:
        print(f"錯誤：找不到 {filepath}")
    return arch_list, animal_list


def generate():
    arch_list, animal_list = load_data(CSV_FILE)
    print(f"建築類：{len(arch_list)} 項 | 動物類：{len(animal_list)} 項")

    if not arch_list:
        print("警告：建築類清單為空")
    if not animal_list:
        print("警告：動物類清單為空")

    dataset = []

    # 標籤統計
    label_count = {}

    for _ in range(NUM_SAMPLES):
        r = random.random()

        # 1. 純建築 (30%)
        if r < 0.30 and arch_list:
            item = random.choice(arch_list)
            name = random.choice(item["names"])
            text = random.choice(TEMPLATES_SINGLE).format(n1=name)
            label = [item["label"]]
            dataset.append({"text": text, "label": label})

        # 2. 純動物 (30%)
        elif r < 0.60 and animal_list:
            item = random.choice(animal_list)
            name = random.choice(item["names"])
            text = random.choice(TEMPLATES_SINGLE).format(n1=name)
            label = [item["label"]]
            dataset.append({"text": text, "label": label})

        # 3. 混合標籤 (25%)
        elif r < 0.85 and arch_list and animal_list:
            arch_item = random.choice(arch_list)
            ani_item  = random.choice(animal_list)
            n_arch = random.choice(arch_item["names"])
            n_ani  = random.choice(ani_item["names"])
            text  = random.choice(TEMPLATES_MIXED).format(n_arch=n_arch, n_ani=n_ani)
            label = [arch_item["label"], ani_item["label"]]
            dataset.append({"text": text, "label": label})

        # 4. 負樣本 (15%) ← 比例提高，標籤給空 list
        else:
            dataset.append({
                "text":  random.choice(NEGATIVE_TEXTS),
                "label": []          # 空 list，代表不觸發任何專家
            })

    random.shuffle(dataset)

    # 統計各標籤分布
    for d in dataset:
        for lbl in d["label"]:
            label_count[lbl] = label_count.get(lbl, 0) + 1
    label_count["(negative)"] = sum(1 for d in dataset if not d["label"])

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        for d in dataset:
            f.write(json.dumps(d, ensure_ascii=False) + "\n")

    print(f"\n成功生成 {len(dataset)} 筆訓練資料 → {OUTPUT_FILE}")
    print("標籤分布：")
    for lbl, cnt in sorted(label_count.items()):
        print(f"  {lbl:20s}：{cnt} 筆")


if __name__ == "__main__":
    generate()