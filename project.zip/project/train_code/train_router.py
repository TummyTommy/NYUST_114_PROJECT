import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset, random_split

# ── 1. 載入資料 ──
data = torch.load("train_dataset.pt")
X = data["embeddings"].float()   # bfloat16 → float32
y = data["labels"].float()

# ── 2. 正規化（L2 norm，讓每個 embedding 長度為 1）──
X = torch.nn.functional.normalize(X, p=2, dim=1)

# ── 3. 切分訓練集 / 驗證集（8:2）──
total = len(X)
val_size   = max(1, int(total * 0.2))
train_size = total - val_size

dataset = TensorDataset(X, y)
train_set, val_set = random_split(dataset, [train_size, val_size],
                                   generator=torch.Generator().manual_seed(42))

train_loader = DataLoader(train_set, batch_size=16, shuffle=True)  # batch 16（資料少）
val_loader   = DataLoader(val_set,   batch_size=16, shuffle=False)

print(f"訓練集：{train_size} 筆 | 驗證集：{val_size} 筆")

# ── 4. MLP Router（加 BatchNorm 穩定訓練）──
class MoERouter(nn.Module):
    def __init__(self, input_dim, num_experts):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(),
            nn.Dropout(0.3),          # 資料少，dropout 調高防過擬合
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(256, num_experts)
        )

    def forward(self, x):
        return self.net(x)            # 輸出 logits，配合 BCEWithLogitsLoss

input_dim   = X.shape[1]             # 3584
num_experts = y.shape[1]             # 25
router = MoERouter(input_dim, num_experts).cuda()

# ── 5. 訓練設定 ──
criterion = nn.BCEWithLogitsLoss()
optimizer = optim.AdamW(router.parameters(), lr=1e-4, weight_decay=1e-3)
scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=100)

# ── 6. 評估函數（Precision / Recall 概念的 F1）──
def evaluate(loader):
    router.eval()
    total_loss = 0
    tp = fp = fn = 0
    with torch.no_grad():
        for bX, by in loader:
            bX, by = bX.cuda(), by.cuda()
            
            logits = router(bX)
            total_loss += criterion(logits, by).item()

            preds = (torch.sigmoid(logits) > 0.5).float()
            tp += (preds * by).sum().item()
            fp += (preds * (1 - by)).sum().item()
            fn += ((1 - preds) * by).sum().item()

    avg_loss = total_loss / len(loader)
    precision = tp / (tp + fp + 1e-9)
    recall    = tp / (tp + fn + 1e-9)
    f1 = 2 * precision * recall / (precision + recall + 1e-9)
    return avg_loss, f1

# ── 7. 訓練迴圈（含 Early Stopping）──
best_val_loss = float("inf")
patience      = 15        # 連續 15 epoch 沒改善就停
no_improve    = 0

print("開始訓練 Router...")
for epoch in range(200):                  # 上限拉到 200，靠 early stopping 控制
    router.train()
    train_loss = 0
    for bX, by in train_loader:
        bX, by = bX.cuda(), by.cuda()
        optimizer.zero_grad()
        loss = criterion(router(bX), by)
        loss.backward()
        optimizer.step()
        train_loss += loss.item()

    scheduler.step()

    # 每 10 epoch 評估一次
    if (epoch + 1) % 10 == 0:
        val_loss, val_f1 = evaluate(val_loader)
        avg_train = train_loss / len(train_loader)
        print(f"Epoch {epoch+1:3d} | Train Loss: {avg_train:.4f} | "
              f"Val Loss: {val_loss:.4f} | Val F1: {val_f1:.3f}")

        # 儲存最佳模型
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            no_improve    = 0
            torch.save(router.state_dict(), "moe_router_best.pth")
            print(f"           最佳模型更新（Val Loss: {val_loss:.4f}）")
        else:
            no_improve += 1
            if no_improve >= patience // 10:
                print(f"⏹  Early stopping at epoch {epoch+1}")
                break

# ── 8. 儲存最終模型 ──
torch.save(router.state_dict(), "moe_router.pth")
print("\n訓練完成")
print(f"   最佳 Val Loss：{best_val_loss:.4f}")
print(f"   模型儲存：moe_router_best.pth（最佳）/ moe_router.pth（最終）")