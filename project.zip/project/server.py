import torch
import gc
import base64
import io
import os
import uuid  
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from diffusers import DiffusionPipeline
from config_manager import ConfigManager
from router_engine import RouterEngine
from prompt_engine import PromptEngine
from generation_engine import GenerationEngine

app = FastAPI()


OUTPUT_DIR = "static/outputs"
os.makedirs(OUTPUT_DIR, exist_ok=True)


MODEL_ID    = "Qwen/Qwen-Image-2512"
ROUTER_PATH = "moe_router_best.pth"
LLM_PATH    = "qwen2.5-1.5b-instruct-q4_k_m.gguf"

print("[INFO] 載入模型中...")
shared_pipe = DiffusionPipeline.from_pretrained(
    MODEL_ID,
    torch_dtype=torch.bfloat16,
    device_map="balanced",
    low_cpu_mem_usage=True
)
config      = ConfigManager("expert_config.json")
router      = RouterEngine(shared_pipe, ROUTER_PATH, "cuda", config)
prompt_llm  = PromptEngine(LLM_PATH)
generator   = GenerationEngine(shared_pipe, config, "cuda")
print("[INFO] 模型載入完成")


class GenerateRequest(BaseModel):
    prompt: str
    steps: int = 50
    guidance_scale: float = 3.0
    seed: int = 42
    ratio: str = "1:1"


class GenerateResponse(BaseModel):
    image_url: str          
    optimized_prompt: str   
    detected_experts: list  

@app.post("/generate", response_model=GenerateResponse)
async def generate(req: GenerateRequest):
    try:
        # 1. Router 偵測
        detected = router.predict(req.prompt)
        if not detected:
            raise HTTPException(status_code=400, detail="未偵測到任何台灣特色元素")

        # 2. Prompt 改寫
        current_experts = []
        for label_id, score in detected:
            info = config.get_info(label_id)
            current_experts.append({
                "name":    info["name"],
                "trigger": info["trigger_word"]
            })
        optimized_prompt = prompt_llm.rewrite(req.prompt, current_experts)

        # 3. 生成圖片
        print(f"[INFO] 收到生成請求: {req.prompt} (Size: {req.ratio}, Steps: {req.steps})")
        image = generator.generate(
            prompt=optimized_prompt,
            detected_labels=[d[0] for d in detected],
            steps=req.steps,
            guidance_scale=req.guidance_scale,
            seed=req.seed,
            ratio=req.ratio
        )

        # --- 4. 將圖片存檔到硬碟 
        filename = f"{uuid.uuid4().hex}.png"
        file_path = os.path.join(OUTPUT_DIR, filename)
        image.save(file_path)
        
        
        image_url = f"/static/outputs/{filename}"

        return GenerateResponse(
            image_url=image_url,
            optimized_prompt=optimized_prompt,
            detected_experts=[
                {"label": d[0], "name": config.get_info(d[0])["name"], "score": round(d[1], 3)}
                for d in detected
            ]
        )

    except Exception as e:
        print(f"[ERROR] {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

    finally:
        gc.collect()
        torch.cuda.empty_cache()


app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
async def root():
    return FileResponse("static/index.html")