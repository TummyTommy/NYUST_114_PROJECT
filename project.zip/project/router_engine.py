import torch
import torch.nn as nn
import torch.nn.functional as F
from diffusers import DiffusionPipeline

 # ── 模組二：Router 模型架構 (不變) ──
class MoERouter(nn.Module):
    def __init__(self, input_dim, num_experts):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(256, num_experts)
        )
    def forward(self, x):
        return self.net(x)

# ── 模組三：RouterEngine (偵測引擎) ──
class RouterEngine:
    def __init__(self, shared_pipe, router_path, device, config_manager):
        self.device = device
        self.cfg = config_manager
        self.pipe = shared_pipe # 接收外部傳入的 pipe
        
        # 只載入小巧的 MLP Router
        self.router = MoERouter(input_dim=3584, num_experts=25).to(device)
        self.router.load_state_dict(torch.load(router_path))
        self.router.eval()

    def predict(self, text, threshold=0.7):
        """輸入文字，回傳偵測到的標籤列表"""
        with torch.no_grad():
            # 1. 提取 Embedding
            prompt_embeds, _ = self.pipe.encode_prompt(
                prompt=text,
                device=self.device,
                num_images_per_prompt=1,
            )
            embedding = prompt_embeds.mean(dim=1).float()
            embedding = F.normalize(embedding, p=2, dim=1).to(self.device)

            # 2. 推理
            logits = self.router(embedding)
            probs = torch.sigmoid(logits)[0]

        # 3. 過濾結果
        results = []
        for i, prob in enumerate(probs):
            if prob > threshold:
                label_id = self.cfg.get_label_id(i)
                results.append((label_id, prob.item()))
        return results