import torch
import os
import gc
from diffusers import DiffusionPipeline
from config_manager import ConfigManager
from router_engine import RouterEngine
from prompt_engine import PromptEngine
from generation_engine import GenerationEngine

# 1. 參數設定
MODEL_ID = "Qwen/Qwen-Image-2512"
ROUTER_PATH = "moe_router_best.pth"
LLM_PATH = "qwen2.5-1.5b-instruct-q4_k_m.gguf"
DEVICE = "cuda"

def main():
    print(f"[INFO] Initializing shared model pipe: {MODEL_ID}")
    
    # 載入完整模型
    shared_pipe = DiffusionPipeline.from_pretrained(
        MODEL_ID, 
        torch_dtype=torch.bfloat16,
        device_map="balanced", 
        low_cpu_mem_usage=True
    )

    # 2. 初始化引擎
    config = ConfigManager("expert_config.json")
    router = RouterEngine(shared_pipe, ROUTER_PATH, DEVICE, config)
    prompt_llm = PromptEngine(LLM_PATH)
    generator = GenerationEngine(shared_pipe, config, DEVICE)

    def run_task(user_text,ratio="16:9"):
        # 1. Router 告訴我們誰中了 (例如中了 arch_03 和 animal_01)
        detected = router.predict(user_text)
        
        # 2. 準備給 LLM 的動態清單
        current_experts = []
        for label_id, score in detected:
            info = config.get_info(label_id)
            current_experts.append({
                "name": info['name'],           # JSON 裡的正式名稱，如 "臺南孔廟"
                "trigger": info['trigger_word'] # LoRA 觸發詞
            })

        # 3. LLM 發揮大腦功能 (處理台/臺、縮寫、錯字)
        # 輸入："一個人在台南孔廟前面拍照"
        # LLM 會理解 "台南孔廟" = "臺南孔廟" 並替換
        optimized_prompt = prompt_llm.rewrite(user_text, current_experts)
        
        print(f"[彈性改寫結果] {optimized_prompt}")
        
        # 4. 生成圖片
        # optimized_prompt 現在已經變成 "一個人在 TainanConfuciusTemple 前面拍照"
        image = generator.generate(optimized_prompt, [d[0] for d in detected],ratio=ratio)
        
        save_path = "moe_output_substituted.png"
        image.save(save_path)
        print(f"[SUCCESS] Image saved to: {save_path}")

    run_task("一隻台灣藍鵲飛過赤嵌樓且要看見完整建築",ratio="1:1")
        # "1:1": (1328, 1328),
        # "16:9": (1664, 928),
        # "9:16": (928, 1664),
        # "4:3": (1472, 1104),
        # "3:4": (1104, 1472),
        # "3:2": (1584, 1056),
        # "2:3": (1056, 1584),
if __name__ == "__main__":
    torch.cuda.empty_cache()
    gc.collect()
    main()