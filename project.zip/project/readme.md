1.專案名稱與簡介
名稱：多標籤Moe-Lora系統以台灣建築風格為例 
核心技術： 基於 Qwen-Image-2512 基底模型，結合多風格建築、動物、文化資產之 LoRA 專家庫，並透過自研 RouterEngine 進行動態調度。

2.環境要求
GPU： NVIDIA GPU (建議顯存 >24GB，本開發環境使用 48GB)。
Python 版本： 3.10+依賴套件： 請參考 requirements.txt。

3.資料夾結構
/static           : 前端網頁與生成圖片輸出目錄 (/outputs)。
/config_manager   : 專家權與路徑配置 (expert_config.json)。
/router_engine    : 負責意圖識別與標籤預測邏輯。
/prompt_engine    : 調用 Local LLM (GGUF) 進行提示詞擴充。
/generation_engine: 執動態權重疊加與影像推論。
/train_code            : [訓練開發目錄]
  ├── 訓練樣本生成.py   : 構建多標籤訓練資料集。
  ├── extract_features.py: 提取圖像之 Embedding 特徵。
  └── train_router.py    : 訓練多標籤分類 Router 模型。
server.py         : FastAPI 後端服務進入點。

4.安裝與執行步驟
安裝套件： pip install -r requirements.txt
模型權重放置： 說明需要將 moe_router_best.pth 與 qwen2.5-1.5b.gguf 放在哪個目錄。
啟動系統： uvicorn server:app --host 0.0.0.0 --port 8000 --reload

5. 模型獲取與存放指南 (Model Acquisition)
本系統涉及多個大型預訓練模型，請依據以下說明進行下載與存放：

5.1 影像生成基座模型 (Stable Diffusion / Qwen-Image)
模型名稱：Qwen/Qwen-Image-2512

下載方式：系統首次執行 server.py 時會透過 Hugging Face diffusers 自動下載。

手動下載 (建議)：若環境網速較慢，建議預先使用 huggingface-cli 下載至指定路徑。

Bash
huggingface-cli download Qwen/Qwen-Image-2512 --local-dir ./models/Qwen-Image-2512
存放路徑：建議存放於專案根目錄下的 /models 資料夾（需於 server.py 同步修改 MODEL_ID 路徑）。

5.2 本地大型語言模型 (Prompt Engine)
模型名稱：qwen2.5-1.5b-instruct-q4_k_m.gguf

獲取來源：請至 Hugging Face 下載 Qwen2.5 1.5B 的 GGUF 版本（推薦使用 QuantFactory 或 bartowski 的量化版本）。

存放路徑：/prompt_engine/models/qwen2.5-1.5b.gguf


5.3 專家權重與路由模型
模型組件,檔案名稱,存放路徑,來源說明
Router 模型,moe_router_best.pth,專案根目錄 /,由 /train/train_router.py 訓練產出
LoRA 專家庫,*.safetensors,/專家lora/,由 /train/lora 訓練產出或外部導入
