import torch
import gc
from diffusers import DiffusionPipeline
import os

class GenerationEngine:
    def __init__(self, shared_pipe, config_manager, device="cuda"):
        self.device = device
        self.cfg    = config_manager
        self.pipe   = shared_pipe
        self.loaded_adapters = []

    def _load_experts_into_pipe(self, detected_labels):
        """載入 LoRA 專家權重"""
        if self.loaded_adapters:
            self.pipe.unload_lora_weights()
            self.loaded_adapters = []

        for label_id in detected_labels:
            info = self.cfg.get_info(label_id)
            path = info.get("file_path")

            if not path or not os.path.exists(path):
                print(f"[WARNING] LoRA file not found: {path}")
                continue

            print(f"[INFO] Loading LoRA: {info['name']} as [{label_id}]")
            self.pipe.load_lora_weights(path, adapter_name=label_id)
            self.loaded_adapters.append(label_id)

    def generate(self, prompt, detected_labels, steps=50, guidance_scale=3.0, seed=42, ratio="1:1"):
        """
        使用靜態權重疊加生成圖片
        """
        aspect_ratios = {
            "1:1": (1328, 1328),
            "16:9": (1664, 928),
            "9:16": (928, 1664),
            "4:3": (1472, 1104),
            "3:4": (1104, 1472),
            "3:2": (1584, 1056),
            "2:3": (1056, 1584),
        }

        # 1. 載入專家
        self._load_experts_into_pipe(detected_labels)

        # 2. 初始化隨機種子
        generator = torch.Generator(device=self.device).manual_seed(seed)

        # 3. 計算靜態疊加權重
        # 專家越多，單個權重需適度下修以防畫面過焦 (Burned)
        # 建議使用 1.0 / sqrt(n) 作為基準，例如：1個=1.0, 2個=0.7, 3個=0.58
        n = max(len(self.loaded_adapters), 1)
        base_weight = 1.0 / (n ** 0.5)

        if self.loaded_adapters:
            # 建立權重列表，所有專家均分權重
            weights = [base_weight] * len(self.loaded_adapters)
            
            # 一次性注入權重，不再隨步驟改變
            self.pipe.set_adapters(self.loaded_adapters, adapter_weights=weights)
            
            # 印出目前疊加狀態供 Debug
            status = " | ".join([f"{a}:{base_weight:.2f}" for a in self.loaded_adapters])
            print(f"[INFO] 權重疊加模式激活: {status}")
        else:
            print("[WARNING] 沒有偵測到專家，將使用基礎模型生成")

        # 4. 執行推理 (移除 callback_on_step_end)
        width, height = aspect_ratios.get(ratio, (1328, 1328))
        print(f"[INFO] 開始生成 (Steps: {steps}, CFG: {guidance_scale}, Seed: {seed}, Ratio: {ratio})")

        image = self.pipe(
            prompt=prompt,
            negative_prompt="low quality, blurry, distorted, lowres, ugly, artifact, bad anatomy",
            width=width,
            height=height,
            num_inference_steps=steps,
            guidance_scale=guidance_scale,
            generator=generator,
        ).images[0]

        # 5. 資源回收
        print("[INFO] 生成完成，清理顯存...")
        self.pipe.unload_lora_weights()
        self.loaded_adapters = []
        gc.collect()
        torch.cuda.empty_cache()

        return image
