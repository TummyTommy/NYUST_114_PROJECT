import json
import os

class ConfigManager:
    def __init__(self, config_path="expert_config.json"):
        if not os.path.exists(config_path):
            raise FileNotFoundError(f"no found：{config_path}")
        
        with open(config_path, "r", encoding="utf-8") as f:
            self.data = json.load(f)
        
        # 建立索引與 Label ID 的映射 (必須與訓練時的順序 0-24 完全一致)
        self.idx_to_label = [f"arch_{i+1:02d}" for i in range(24)] + ["animal_01"]
        self.num_experts  = len(self.idx_to_label)
    def get_label_id(self, index):
        return self.idx_to_label[index]

    def get_info(self, label_id):
        return self.data.get(label_id, {"name": "未知專家", "trigger_word": ""})
